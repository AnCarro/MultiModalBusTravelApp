package com.example.travelapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Fragment;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;


@SuppressWarnings("ALL")
public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback,
                                                GoogleMap.OnMapLongClickListener   {

    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private LatLng curLoc = null;
    private RequestQueue rQueue;
    private Context context;
    private static HashMap<String, Bus> Buses = new HashMap<String, Bus>();
    private Marker UserLoc;
    private TextView topTextView;
    private TextView bottomTextView;
    SupportMapFragment mapFragment;


    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        context = this.getApplicationContext();

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);
        Toolbar mainToolBar = (Toolbar) findViewById (R.id.mainToolBar);
        setSupportActionBar(mainToolBar);


        /*  ViewGroup.LayoutParams params = mapFragment.getView().getLayoutParams();
        params.height = params.MATCH_PARENT;
        mapFragment.getView().setLayoutParams(params);*/



        if (checkPermissions()) {
          requestPermissions();
        }
        fusedLocationClient.getLastLocation()
            .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    // Got last known location. In some rare situations this can be null.
                    if (location != null) {
                        double lat = location.getLatitude();
                        double lng = location.getLongitude();
                        System.out.println("lat: " + lat + "lng: "+ lng);
                        curLoc = new LatLng(lat, lng);
                        mMap.addMarker(new MarkerOptions()
                                .position(curLoc)
                                .title("you")
                                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
                        );
                        mMap.moveCamera(CameraUpdateFactory.newLatLng(curLoc));


                    } else {
                        System.out.println("Loc = null");
                        requestNewLocationData();
                    }
                }
            });

        callAsynchronousTask();
        //rQueue = Volley.newRequestQueue(this);
      /*  Timer t = new Timer();
       TimerTask tt = new TimerTask() {
           @Override
           public void run() {
               SetBusPositions();
               System.out.println("HERE");
           }
       };
        t.schedule(tt, 3000L);*/
                //SetBusPositions();



    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setOnMapLongClickListener(this);
        mMap.setMinZoomPreference(10);
        addStops();

        if(curLoc != null) {
            UserLoc = mMap.addMarker(new MarkerOptions()
                    .position(curLoc)
                    .title("you")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
            );
            mMap.moveCamera(CameraUpdateFactory.newLatLng(curLoc));
        }
        topTextView = (TextView) findViewById(R.id.FirstInfo);
        bottomTextView = (TextView) findViewById(R.id.DistanceBar);
    }

    @Override
    public void onMapLongClick(LatLng point) {
        System.out.println("onMapLongClick: " + point.latitude + ", " + point.longitude);
        GetTimeToDest(point, "walking");
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(
                this,
                new String[] {
                        Manifest.permission
                                .ACCESS_COARSE_LOCATION,
                        Manifest.permission
                                .ACCESS_FINE_LOCATION },
                44);
    }


    private boolean checkPermissions()
    {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                                                                            != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                                                                            != PackageManager.PERMISSION_GRANTED;

        // If we want background location
        // on Android 10.0 and higher,
        // use:
        /* ActivityCompat
                .checkSelfPermission(
                    this,
                    Manifest.permission
                        .ACCESS_BACKGROUND_LOCATION)
            == PackageManager.PERMISSION_GRANTED
        */
    }

    private void callAsynchronousTask() {
        final Handler handler = new Handler();
        Timer timer = new Timer();
        TimerTask doAsynchronousTask = new TimerTask() {
            @Override
            public void run() {
                handler.post(new Runnable() {
                    public void run() {
                        try {
                            ServerRequests performBackgroundTask = new ServerRequests(context, mMap, topTextView);
                            // RepeatedOperation this class is the class that extends AsyncTask
                            performBackgroundTask.execute();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        };
        timer.schedule(doAsynchronousTask, 0, 4000); //execute in every 4000 ms
    }


    @SuppressLint("MissingPermission")
    private void requestNewLocationData()
    {

        // Initializing LocationRequest
        // object with appropriate methods
        LocationRequest mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority( LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(50000);
        mLocationRequest.setFastestInterval(500);
        mLocationRequest.setNumUpdates(1);

        // setting LocationRequest
        // on FusedLocationClient
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        fusedLocationClient.requestLocationUpdates(mLocationRequest,mLocationCallback,Looper.myLooper());
    }

    private LocationCallback
            mLocationCallback
            = new LocationCallback() {

        @Override
        public void onLocationResult(
                LocationResult locationResult)
        {
            Location mLastLocation
                    = locationResult
                    .getLastLocation();
            System.out.println("Latitude: " + mLastLocation.getLatitude()+ "");
            System.out.println("Longitude: " + mLastLocation.getLongitude()+ "");
            curLoc = new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude());
            mMap.addMarker(new MarkerOptions().position(curLoc).title("you"));
            mMap.moveCamera(CameraUpdateFactory.newLatLng(curLoc));
        }
    };

   /* private void getDistanceMatrix(LatLng dest) {
        DirectionsService directionServce = new GoogleMap

    }*/

    private void addStops() {
        Marker EvansdaleCrossingMarker = mMap.addMarker(new MarkerOptions()
                .position(new LatLng(39.648, -79.973))
                .title("Evansdale Crossing")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
        );
        Marker KrogerPattesonMarker = mMap.addMarker(new MarkerOptions()
                .position(new LatLng(39.651, -79.968))
                .title("Kroger - Patteson Dr.")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
        );
        Marker TowersMarker = mMap.addMarker(new MarkerOptions()
                .position(new LatLng(39.6494, -79.9659))
                .title("Towers")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
        );
        Marker LawSchoolMarker = mMap.addMarker(new MarkerOptions()
                .position(new LatLng(39.6483, -79.9597))
                .title("Law School Drive")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
        );
        Marker Grand6thMarker = mMap.addMarker(new MarkerOptions()
                .position(new LatLng(39.6422, -79.9601))
                .title("Grant & 6th St")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
        );
        Marker Grant4thMarker = mMap.addMarker(new MarkerOptions()
                .position(new LatLng(39.6408, -79.9581))
                .title("Grant & 4th St")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
        );
        Marker Grant1stMarker = mMap.addMarker(new MarkerOptions()
                .position(new LatLng(39.6380, -79.9560))
                .title("Grant & 1st St")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
        );
        Marker LSBSunnysideMarker = mMap.addMarker(new MarkerOptions()
                .position(new LatLng(39.6373, -79.9559))
                .title("LSB / Sunnyside")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
        );
        Marker Beechurst1stMarker = mMap.addMarker(new MarkerOptions()
                .position(new LatLng(39.6378, -79.9578))
                .title("Beechurst & 1st")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
        );
        Marker Beechurst3rdMarker = mMap.addMarker(new MarkerOptions()
                .position(new LatLng(39.6389, -79.9587))
                .title("Beechurst and 3rd")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
        );
        Marker Beechurst6thMarker = mMap.addMarker(new MarkerOptions()
                .position(new LatLng(39.6411, -79.9615))
                .title("Beechurst and 6th")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
        );
        Marker Beechurst8thMarker = mMap.addMarker(new MarkerOptions()
                .position(new LatLng(39.6424, -79.9632))
                .title("Beechurst and 8th")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
        );
    }

    public void GetTimeToDest(LatLng dest, String mode) {
        //mode can be driving, walking, bicycling, transit
       String url = "https://maps.googleapis.com/maps/api/distancematrix/json?parameters?";
       String origins = String.valueOf(curLoc.latitude) +","+String.valueOf(curLoc.longitude);
       String destinations= String.valueOf(dest.latitude) +","+String.valueOf(dest.longitude);
       String travelMode = mode;
       String units = "imperial";
       String key = "AIzaSyD1XgaLSdCgTMe9tOp4EBSSkETH-KsYL3g";
       String DirReq = url+"units="+units+"&origins="+origins+"&destinations="+destinations+"&mode="+mode+"&key="+key;
       int SendMethod = Request.Method.GET;
       System.out.println("DirReq: " + DirReq);
       RequestQueue Queue = ServerRequestsQueue.getInstance(context.getApplicationContext()).getRequestQueue();
       JsonObjectRequest JOR = new JsonObjectRequest(SendMethod, DirReq, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject resp) {
                //System.out.println("Response destination is: " + resp.toString());
                try {
                    JSONArray rows = resp.getJSONArray("rows");
                        //System.out.println("rows: " + rows);
                        JSONObject row = rows.getJSONObject(0);
                        JSONObject values = row.getJSONArray("elements").getJSONObject(0);
                        System.out.println("values: " + values);
                            JSONObject distance = values.getJSONObject("distance");
                                String distText = distance.getString("text");
                                String distValue = distance.getString("value");
                            JSONObject duration = values.getJSONObject("duration");
                                String durText = duration.getString("text");
                                String durValue = duration.getString("value");

                    bottomTextView.setText("Distance: " + distText + "\n" +
                            "Time: " + durText);
/*                    bottomTextView.setVisibility(View.VISIBLE);
                    bottomTextView.setHeight(80);
                    ViewGroup.LayoutParams params = mapFragment.getView().getLayoutParams();
                    params.height = 1000;
                    mapFragment.getView().setLayoutParams(params);*/

                 //   String elements = dist.getString("elements");
                //    System.out.println("elements: " + elements);
                 //   System.out.println("Dist: " + dist);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            public void onErrorResponse(VolleyError error) {
                System.out.println("Ouch, Failure: " + error.getLocalizedMessage() + " " + error.getMessage());
            }
        });
        Queue.add(JOR);

    }

    public void fullScreenMap() {
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
    }

}
