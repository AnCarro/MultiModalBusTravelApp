package com.example.travelapp;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class Bus {
    public String id;
    public LatLng location;
    public LatLng prevLocation = null;
    public Marker marker;
    public String title;

    public Bus (String busId, double busLat, double busLng, GoogleMap map) {
        id = busId;
        location = new LatLng(busLat, busLng);
        marker = map.addMarker(new MarkerOptions().position(location));
    }

    public Bus(String busId, LatLng busLoc, GoogleMap map) {
        id = busId;
        location = busLoc;
        marker = map.addMarker(new MarkerOptions().position(location));
    }

    public Bus(int busId, LatLng busLoc, GoogleMap map) {
        id = Integer.toString(busId);
        location = busLoc;
        marker = map.addMarker(new MarkerOptions().position(location));
    }

    public Bus(int busId, double busLat, double busLng, GoogleMap map) {
        id = Integer.toString(busId);
        location = new LatLng(busLat, busLng);
        marker = map.addMarker(new MarkerOptions().position(location));
    }

    public Bus (String busId, double busLat, double busLng, String title, GoogleMap map) {
        id = busId;
        location = new LatLng(busLat, busLng);
        this.title = title;
        marker = map.addMarker(new MarkerOptions().position(location).title(this.title));
    }

    public Bus(String busId, LatLng busLoc, String title, GoogleMap map) {
        id = busId;
        location = busLoc;
        this.title = title;
        marker = map.addMarker(new MarkerOptions().position(location).title(this.title));
    }

    public Bus(int busId, LatLng busLoc, String title, GoogleMap map) {
        id = Integer.toString(busId);
        location = busLoc;
        this.title = title;
        marker = map.addMarker(new MarkerOptions().position(location).title(this.title));
    }

    public Bus(int busId, double busLat, double busLng, String title, GoogleMap map) {
        id = Integer.toString(busId);
        location = new LatLng(busLat, busLng);
        this.title = title;
        marker = map.addMarker(new MarkerOptions().position(location).title(this.title));
    }

    public void Move(LatLng newLoc, GoogleMap map) {
        prevLocation = location;
        location = newLoc;
        marker.setPosition(location);
    }

}
